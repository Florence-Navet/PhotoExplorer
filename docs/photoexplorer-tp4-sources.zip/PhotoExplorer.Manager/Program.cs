using FluentValidation;
using Microsoft.Extensions.DependencyInjection;
using PhotoExplorer.Components;
using PhotoExplorer.Components.Services;
using PhotoExplorer.Manager.Components;
using PhotoExplorer.Manager.Services;
using PhotoExplorer.Models.Requests;
using PhotoExplorer.Models.Validation;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddHttpClient();
builder.Services.AddHttpClient("api", (sp, client) =>
{
    var configuration = sp.GetRequiredService<IConfiguration>();
    client.BaseAddress = new Uri(configuration["Api:Url"]!);
});
builder.Services.AddScoped<IPhotoService, ServerPhotoService>();
builder.Services.AddScoped<IManagerPhotoService, ServerPhotoService>();
builder.Services.AddScoped<IValidator<PhotoUpdateModel>, PhotoUpdateModelValidator>();

builder.Services.AddScoped<PlatformService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
