﻿using PhotoExplorer.Components.Services;
using PhotoExplorer.Models.Requests;

namespace PhotoExplorer.Manager.Services;

public interface IManagerPhotoService : IPhotoService
{
    Task Update(string id, PhotoUpdateModel model);
    Task Delete(string id);
}
