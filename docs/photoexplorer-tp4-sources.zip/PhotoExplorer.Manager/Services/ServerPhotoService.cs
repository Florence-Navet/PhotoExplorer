﻿using PhotoExplorer.Components.Models;
using PhotoExplorer.Components.Services;
using PhotoExplorer.Models.Requests;
using System.Reflection;

namespace PhotoExplorer.Manager.Services;

public class ServerPhotoService : IManagerPhotoService
{
    private readonly IHttpClientFactory factory;

    public ServerPhotoService(
        IHttpClientFactory factory)
    {
        this.factory = factory;
    }

    public async Task Delete(string id)
    {
        using var httpClient = factory.CreateClient("api");
        await httpClient.DeleteAsync("photos/" + id);
    }

    public async Task<Photo?> GetPhotoById(string id)
    {
        using var httpClient = factory.CreateClient("api");
        var result = await httpClient.GetFromJsonAsync<Photo>("photos/" + id);
        return result;
    }

    public async Task<List<Photo>?> GetPhotosFromApi()
    {
        using var httpClient = factory.CreateClient("api");
        var result = await httpClient.GetFromJsonAsync<List<Photo>>("photos/all");
        return result;
    }

    public async Task Update(string id, PhotoUpdateModel model)
    {
        using var httpClient = factory.CreateClient("api");
        await httpClient.PutAsJsonAsync("photos/" + id, model);
    }
}
