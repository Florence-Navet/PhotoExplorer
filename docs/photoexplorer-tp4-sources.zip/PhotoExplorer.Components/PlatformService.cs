﻿using Microsoft.AspNetCore.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoExplorer.Components;

public enum BlazorPlatform
{
    Server,
    WebAssembly,
    Hybrid
}

public class PlatformService
{
    public BlazorPlatform Platform { get; }

    public PlatformService(NavigationManager navigation)
    {
        Platform = navigation.GetType().FullName switch
        {
            string s when s.Contains(".Server.") => BlazorPlatform.Server,
            string s when s.Contains(".WebAssembly.") => BlazorPlatform.WebAssembly,
            _ => BlazorPlatform.Hybrid,
        };
    }
}
