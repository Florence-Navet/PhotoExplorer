﻿using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PhotoExplorer.Components;
using PhotoExplorer.Components.Services;
using PhotoExplorer.Explorer.Services;
using PhotoExplorer.Mobile.Services;
using PhotoExplorer.Models.Requests;
using PhotoExplorer.Models.Validation;

namespace PhotoExplorer.Mobile;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
            });

        builder.Services.AddMauiBlazorWebView();

#if DEBUG
        builder.Services.AddBlazorWebViewDeveloperTools();
        builder.Logging.AddDebug();
#endif

        builder.Services.AddScoped<IPhotoService, HybridPhotoService>();
        builder.Services.AddScoped<IMobilePhotoService, HybridPhotoService>();
        builder.Services.AddScoped<HttpClient>(_ => new HttpClient());
        builder.Services.AddScoped<IValidator<PhotoUploadModel>, PhotoUploadModelValidator>();
        builder.Services.AddScoped<PlatformService>();

        var conf = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json")
            .Build();
        builder.Configuration.AddConfiguration(conf);

        return builder.Build();
    }
}
