﻿using Microsoft.Extensions.Configuration;
using Microsoft.Maui.Controls;
using PhotoExplorer.Components.Models;
using PhotoExplorer.Components.Services;
using PhotoExplorer.Mobile.Services;
using PhotoExplorer.Models.Requests;
using System.Net.Http.Json;
using System.Text.Json;

namespace PhotoExplorer.Explorer.Services;

public class HybridPhotoService : IMobilePhotoService
{
    private readonly HttpClient client;
    private readonly IConfiguration _configuration;

    public HybridPhotoService(
        HttpClient client,
        IConfiguration configuration)
    {
        this.client = client;
        _configuration = configuration;
    }

    public async Task<Photo?> Create(PhotoUploadModel model)
    {
        var result = await client.PostAsJsonAsync(_configuration["Api:Url"] + "/photos/", model);
        if (result.IsSuccessStatusCode)
        {
            return JsonSerializer.Deserialize<Photo>(await result.Content.ReadAsStringAsync());
        }
        return null;
    }

    public Task<Photo> GetPhotoById(string id)
    {
        return client.GetFromJsonAsync<Photo>(_configuration["Api:Url"] + "/photos/" + id);
    }

    public Task<List<Photo>?> GetPhotosFromApi()
    {
        return client.GetFromJsonAsync<List<Photo>>(_configuration["Api:Url"] + "/photos");
    }
}
