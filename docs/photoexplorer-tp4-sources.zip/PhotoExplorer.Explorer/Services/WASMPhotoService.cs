﻿using PhotoExplorer.Components.Models;
using PhotoExplorer.Components.Services;
using System.Net.Http.Json;

namespace PhotoExplorer.Explorer.Services;

public class WASMPhotoService : IPhotoService
{
    private readonly HttpClient client;
    private readonly IConfiguration _configuration;

    public WASMPhotoService(
        HttpClient client,
        IConfiguration configuration)
    {
        this.client = client;
        _configuration = configuration;
    }

    public Task<Photo?> GetPhotoById(string id)
    {
        return client.GetFromJsonAsync<Photo?>(_configuration["Api:Url"] + "/photos/" + id);
    }

    public Task<List<Photo>?> GetPhotosFromApi()
    {
        return client.GetFromJsonAsync<List<Photo>>(_configuration["Api:Url"] + "/photos");
    }
}
