﻿using FluentValidation;
using PhotoExplorer.Models.Requests;

namespace PhotoExplorer.Models.Validation;

public class PhotoUploadModelValidator : AbstractValidator<PhotoUploadModel>
{
    public PhotoUploadModelValidator()
    {
        RuleFor(p => p.Author)
            .NotEmpty();

        RuleFor(p => p.Description)
            .NotEmpty();

        RuleFor(p => p.Name)
            .NotEmpty();

        RuleFor(p => p.Base64Content)
            .NotEmpty();
    }
}
