using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PhotoExplorer.Api.Data;
using PhotoExplorer.Api.Data.Models;
using PhotoExplorer.Models.Validation;
using PhotoExplorer.Models.Requests;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors();

builder.Services.AddDbContext<PhotoExplorerDbContext>(opt => opt.UseSqlite("Filename=photos.db"));
builder.Services.AddScoped<IValidator<PhotoUpdateModel>, PhotoUpdateModelValidator>();
builder.Services.AddScoped<IValidator<PhotoUploadModel>, PhotoUploadModelValidator>();

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = "https://hts-learning.eu.auth0.com/";
        options.Audience = "https://photoexplorerapi";
    });

builder.Services.AddAuthorization(o =>
{
    o.AddPolicy("admin", p => p.RequireRole("admin"));
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    using (var ctx = scope.ServiceProvider.GetRequiredService<PhotoExplorerDbContext>())
    {
        await ctx.Database.MigrateAsync();
    }
}

app.UseCors(p =>
{
    p.AllowAnyHeader()
    .AllowAnyMethod()
    .AllowCredentials()
    .WithOrigins("http://localhost:5214");
});

app.UseStaticFiles();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/photos/{id:guid}", async (
    HttpContext httpContext,
    [FromServices] PhotoExplorerDbContext ctx,
    [FromRoute] Guid id) =>
{
    var photo = await ctx.Photos.FindAsync(id);
    if (photo is not null)
    {
        if (httpContext.User.Identity!.IsAuthenticated
        && !httpContext.User.IsInRole("admin")
        && photo.UserId != httpContext.User.Identity.Name)
        {
            return Results.Forbid();
        }
        return Results.Ok(photo);
    }
    return Results.NotFound();
});

app.MapGet("/photos", async (
    HttpContext httpContext,
    [FromServices] PhotoExplorerDbContext ctx) =>
{
    var photoQueryable = ctx.Photos.Where(p => p.Published);
    if (httpContext.User.Identity!.IsAuthenticated && !httpContext.User.IsInRole("admin"))
    {
        var userId = httpContext.User.FindFirst(ClaimTypes.NameIdentifier)!.Value;
        photoQueryable = photoQueryable.Where(p => p.UserId == userId);
    }
    var photos = await photoQueryable.ToListAsync();
    return Results.Ok(photos);
});

app.MapGet("/photos/all", async (
    HttpContext httpContext,
    [FromServices] PhotoExplorerDbContext ctx) =>
{
    var photos = await ctx.Photos.ToListAsync();
    return Results.Ok(photos);
})
.RequireAuthorization("admin");

app.MapPost("/photos", async (
    [FromBody] PhotoUploadModel photo,
    [FromServices] PhotoExplorerDbContext ctx,
    [FromServices] IValidator<PhotoUploadModel> validator,
    HttpContext httpContext,
    CancellationToken cancellationToken = default) =>
{
    var validationResult = validator.Validate(photo);
    if (!validationResult.IsValid)
    {
        return Results.BadRequest(validationResult.Errors);
    }
    var dbPhoto = new Photo
    {
        UserId = httpContext.User.FindFirst(c => c.Type == ClaimTypes.NameIdentifier)!.Value,
        Author = photo.Author,
        Description = photo.Description,
        Path = photo.Name,
        Published = false
    };
    var photoData = Convert.FromBase64String(photo.Base64Content);
    await File.WriteAllBytesAsync("wwwroot/photos/" + photo.Name, photoData, cancellationToken);

    ctx.Photos.Add(dbPhoto);
    await ctx.SaveChangesAsync(cancellationToken);

    return Results.Created("/photos/" + dbPhoto.Id, photo);
})
.RequireAuthorization();

app.MapPut("/photos/{id:guid}", async (
    [FromRoute] Guid id,
    [FromBody] PhotoUpdateModel photo,
    [FromServices] PhotoExplorerDbContext ctx,
    [FromServices] IValidator<PhotoUpdateModel> validator) =>
{
    var validationResult = validator.Validate(photo);
    if (!validationResult.IsValid)
    {
        return Results.BadRequest(validationResult.Errors);
    }
    var dbPhoto = await ctx.Photos.FirstOrDefaultAsync(p => p.Id == id);
    if (dbPhoto is not null)
    {
        dbPhoto.Description = photo.Description;
        dbPhoto.Author = photo.Author;
        dbPhoto.Published = photo.Published;

        ctx.Photos.Update(dbPhoto);
        await ctx.SaveChangesAsync();
        return Results.Accepted();
    }
    return Results.NotFound();
})
.RequireAuthorization("admin");

app.MapDelete("/photos/{id:guid}", async (
    [FromServices] PhotoExplorerDbContext ctx,
    [FromRoute] Guid id
    ) =>
{
    var dbPhoto = await ctx.Photos.FirstOrDefaultAsync(p => p.Id == id);
    if (dbPhoto is not null)
    {
        string photoPath = "wwwroot/photos/" + dbPhoto.Path;
        if (File.Exists(photoPath))
        {
            File.Delete(photoPath);
        }

        ctx.Photos.Remove(dbPhoto);
        await ctx.SaveChangesAsync();
    }

    return Results.Accepted();
})
.RequireAuthorization("admin");


app.Run();
