﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PhotoExplorer.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddUserId : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "UserId",
                table: "Photos",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("2ca16a6d-fe63-4351-bd05-f669f615f4cc"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab7133c950252e008e40" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("4f159947-627c-4070-9532-50a4d3a6c6ef"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab88a6c4b20d22f31b80" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("5d839739-8291-4c98-bc3d-5f619cba1af7"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab7133c950252e008e40" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("7dcda0ab-a7d5-4b97-908e-50dc94306236"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab99161f8843b470fc53" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("921c1f8b-5671-4a6e-b12c-916079bc7844"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab88a6c4b20d22f31b80" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("948e198d-a7b1-40df-8d96-e29891fec311"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab99161f8843b470fc53" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("a20d1103-e141-439b-bed1-68fb101de295"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab7133c950252e008e40" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("bd7bf2e7-1dac-47de-8709-407f8a3b6838"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab99161f8843b470fc53" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("cebb5c21-327c-443c-9146-5d93ce5beebd"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab7133c950252e008e40" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("da25fdad-cd44-46c3-8871-bbd61cfa13b9"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab99161f8843b470fc53" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("dfba52a5-d319-48a3-9ebe-b85836c5a30c"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab88a6c4b20d22f31b80" });

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("e8bdf7f7-89c4-47ac-9b29-092e773af3fb"),
                columns: new[] { "Published", "UserId" },
                values: new object[] { true, "auth0|65e5ab88a6c4b20d22f31b80" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UserId",
                table: "Photos");

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("2ca16a6d-fe63-4351-bd05-f669f615f4cc"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("4f159947-627c-4070-9532-50a4d3a6c6ef"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("5d839739-8291-4c98-bc3d-5f619cba1af7"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("7dcda0ab-a7d5-4b97-908e-50dc94306236"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("921c1f8b-5671-4a6e-b12c-916079bc7844"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("948e198d-a7b1-40df-8d96-e29891fec311"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("a20d1103-e141-439b-bed1-68fb101de295"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("bd7bf2e7-1dac-47de-8709-407f8a3b6838"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("cebb5c21-327c-443c-9146-5d93ce5beebd"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("da25fdad-cd44-46c3-8871-bbd61cfa13b9"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("dfba52a5-d319-48a3-9ebe-b85836c5a30c"),
                column: "Published",
                value: false);

            migrationBuilder.UpdateData(
                table: "Photos",
                keyColumn: "Id",
                keyValue: new Guid("e8bdf7f7-89c4-47ac-9b29-092e773af3fb"),
                column: "Published",
                value: false);
        }
    }
}
