﻿using System.ComponentModel;

namespace PhotoExplorer.Api.Data.Models;

public class Photo
{
    public Guid Id { get; set; }
    public string Path { get; set; }
    public string Author { get; set; }
    public string Description { get; set; }
    public bool Published { get; set; }
    public string UserId { get; set; }
}
