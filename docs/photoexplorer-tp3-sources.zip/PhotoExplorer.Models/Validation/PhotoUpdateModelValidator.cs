﻿using FluentValidation;
using PhotoExplorer.Models.Requests;

namespace PhotoExplorer.Models.Validation;

public class PhotoUpdateModelValidator : AbstractValidator<PhotoUpdateModel>
{
    public PhotoUpdateModelValidator()
    {
        RuleFor(p => p.Author)
            .NotEmpty();

        RuleFor(p => p.Description)
            .NotEmpty();
    }
}
