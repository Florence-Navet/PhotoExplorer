﻿namespace PhotoExplorer.Models.Requests;

public class PhotoUploadModel
{
    public string Base64Content { get; set; }
    public string Name { get; set; }
    public string Author { get; set; }
    public string Description { get; set; }
}
