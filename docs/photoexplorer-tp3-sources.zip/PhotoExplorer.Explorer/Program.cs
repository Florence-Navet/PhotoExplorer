using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using PhotoExplorer.Components;
using PhotoExplorer.Components.Services;
using PhotoExplorer.Explorer.Components;
using PhotoExplorer.Explorer.Services;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");


builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });
builder.Services.AddScoped<IPhotoService, WASMPhotoService>();
builder.Services.AddScoped<PlatformService>();

await builder.Build().RunAsync();
