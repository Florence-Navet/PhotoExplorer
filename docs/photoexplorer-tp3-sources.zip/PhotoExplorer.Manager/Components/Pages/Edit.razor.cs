using Microsoft.AspNetCore.Components;
using PhotoExplorer.Components.Models;
using PhotoExplorer.Components.Services;
using PhotoExplorer.Manager.Services;
using PhotoExplorer.Models.Requests;

namespace PhotoExplorer.Manager.Components.Pages;

public partial class Edit
{
    [Parameter]
    public string Id { get; set; }

    [Inject] private IManagerPhotoService PhotoService { get; set; } = default!;
    [Inject] private NavigationManager NavigationManager { get; set; } = default!;

    private Photo? _photo;

    protected override async Task OnInitializedAsync()
    {
        if (!string.IsNullOrEmpty(Id))
        {
            _photo = await PhotoService.GetPhotoById(Id);
        }
        if (_photo is null)
        {
            NavigationManager.NavigateTo("/", replace: true);
        }
    }

    private async Task SavePhoto()
    {
        if (_photo is null) return;

        var model = new PhotoUpdateModel
        {
            Author = _photo.Author,
            Description = _photo.Description,
            Published = _photo.Published
        };

        await PhotoService.Update(Id, model);
        NavigationManager.NavigateTo("/");
    }
}