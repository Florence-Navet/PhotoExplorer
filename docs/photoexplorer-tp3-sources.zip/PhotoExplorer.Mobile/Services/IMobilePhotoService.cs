﻿using PhotoExplorer.Components.Models;
using PhotoExplorer.Components.Services;
using PhotoExplorer.Models.Requests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoExplorer.Mobile.Services;

public interface IMobilePhotoService : IPhotoService
{
    Task<Photo?> Create(PhotoUploadModel model);
}
