using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using PhotoExplorer.Components.Models;
using PhotoExplorer.Mobile.Services;
using PhotoExplorer.Models.Requests;

namespace PhotoExplorer.Mobile.Pages;

public partial class Create
{
    [Inject] IMobilePhotoService PhotoService { get; set; } = default!;
    [Inject] NavigationManager Navigation { get; set; } = default!;

    private Photo _photo = new();
    private string? _photoBase64String;
    private string? _name;

    private async Task SavePhoto()
    {
        if (string.IsNullOrEmpty(_photoBase64String) || string.IsNullOrEmpty(_name)) return;

        var model = new PhotoUploadModel
        {
            Author = _photo.Author,
            Description = _photo.Description,
            Base64Content = _photoBase64String,
            Name = _name
        };

        await PhotoService.Create(model);
        Navigation.NavigateTo("/");
    }

    private async Task OnPhotoUpload(InputFileChangeEventArgs args)
    {
        using var stream = args.File.OpenReadStream();
        using var memStream = new MemoryStream();

        await stream.CopyToAsync(memStream);
        memStream.Position = 0;

        _photoBase64String = Convert.ToBase64String(memStream.ToArray());
        _name = args.File.Name;
    }
}