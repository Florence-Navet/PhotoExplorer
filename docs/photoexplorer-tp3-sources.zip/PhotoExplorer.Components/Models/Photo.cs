﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoExplorer.Components.Models;

public class Photo
{
    public string Id { get; set; }
    public string Path { get; set; }
    public string Author { get; set; }
    public string Description { get; set; }
    public bool Published { get; set; }

}
