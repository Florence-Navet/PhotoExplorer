﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoExplorer.Models.Requests;

public class PhotoUpdateModel
{
    public string Author { get; set; }
    public string Description { get; set; }
	public bool Published { get; set; }
}
